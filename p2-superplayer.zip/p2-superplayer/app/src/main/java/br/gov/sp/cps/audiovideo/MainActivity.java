package br.gov.sp.cps.audiovideo;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private VideoView videoView;
    private SeekBar videoSeekBar;
    private TextView textTempo;

    private Button btnVideoA, btnVideoB, btnVideoC;

    private ImageView imgPausePlay;

    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        videoView = findViewById(R.id.videoView);
        videoSeekBar = findViewById(R.id.videoSeekBar);
        textTempo = findViewById(R.id.textTempo);
        btnVideoA = findViewById(R.id.btnVideoA);
        btnVideoB = findViewById(R.id.btnVideoB);
        btnVideoC = findViewById(R.id.btnVideoC);
        imgPausePlay = findViewById(R.id.imagePausePlay);
        imgPausePlay.setTag("pause");


        btnVideoA.setOnClickListener(v ->{
            escolherVideo('a');
        });

        btnVideoB.setOnClickListener(v ->{
            escolherVideo('b');
        });

        btnVideoC.setOnClickListener(v ->{
            escolherVideo('c');
        });

        imgPausePlay.setOnClickListener(v -> {
            if (imgPausePlay.getTag().equals("pause")){
                videoView.pause();
                imgPausePlay.setImageResource(android.R.drawable.ic_media_play);
                imgPausePlay.setTag("play");
            } else {
                videoView.start();
                imgPausePlay.setImageResource(android.R.drawable.ic_media_pause);
                imgPausePlay.setTag("pause");
            }
        });



        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                videoSeekBar.setMax(videoView.getDuration());


                handler.post(atualizaSeekBar);




                videoView.start();
            }
        });


        videoSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser){

                    videoView.seekTo(progress);
                }
                atualizaTextTempo();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void escolherVideo(char video){
        imgPausePlay.setImageResource(android.R.drawable.ic_media_pause);
        imgPausePlay.setTag("pause");
        int videoEscolhido;
        if (video == 'a'){
            videoEscolhido = R.raw.videoa;
        } else if (video == 'b'){
            videoEscolhido = R.raw.videob;
        } else {
            videoEscolhido = R.raw.videoc;
        }
        Uri videoUri = Uri.parse("android.resource://" +
                getPackageName() + "/" + videoEscolhido);
        videoView.setVideoURI(videoUri);
    }


    private Runnable atualizaSeekBar = new Runnable() {
        @Override
        public void run() {
            if(videoView.isPlaying()){
                videoSeekBar.setProgress(videoView.getCurrentPosition());
                atualizaTextTempo();
            }
            handler.postDelayed(this, 1000);
        }
    };


    private void atualizaTextTempo(){
        int tempoAtual = videoView.getCurrentPosition();
        int tempoTotal = videoView.getDuration();

        String tempoFormatado = formataTempo(tempoAtual) + " / " +
                formataTempo(tempoTotal);
        textTempo.setText(tempoFormatado);
    }


    private String formataTempo(int tempo){
        int min = (tempo / 1000) / 60;
        int sec = (tempo / 1000) % 60;

        return String.format("%02d:%02d", min, sec);
    }



}